﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Land
    {
        private string strLand;
        public string land
        {
            get { return strLand; }
            set { strLand = value; }
        }

        public Land(string pstrland)
        {
            strLand = pstrland;
        }
    }
}
