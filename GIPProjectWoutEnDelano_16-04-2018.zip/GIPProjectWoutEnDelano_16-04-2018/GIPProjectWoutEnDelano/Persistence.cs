﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace GIPProjectWoutEnDelano
{
    class Persistence
    {
        private string _connection;

        public Persistence()
        {
            _connection = "server = localhost; user id = root; database = gip; password = 'Test123'";
        }

        public string AddNat(Nationaliteit item)
        {
            int intResult = 0;
            string strResult = string.Empty;
            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into nationaliteit(nationaliteit) values('" + item.Nationality + "')");

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            if (intResult != -1)
            {
                strResult = "Het ingegeven is toegevoegd.";
            }
            else
            {
                strResult = "Het toevoegen is mislukt.";
            }
                return strResult;
        }

        public string AddLand(Land item)
        {
            int intResult = 0;
            string strResult = string.Empty;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into Land(naam) values('" + item.land + "')");

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            if (intResult != -1)
            {
                strResult = "Het ingegeven is toegevoegd.";
            }
            else
            {
                strResult = "Het toevoegen is mislukt.";
            }

            return strResult;
        }

        public string AddGemeente(gemeente item)
        {
            int intResult;
            string strResult = string.Empty;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gemeente(Postcode, Naam) values('" + item.Postcode + "', '" + item.Naam + "')");

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            if (intResult != -1)
            {
                strResult = "Het ingegeven is toegevoegd.";
            }
            else
            {
                strResult = "Het toevoegen is mislukt.";
            }

            return strResult;
        }

        public int AddLeerling(Leerling item)
        {
            int intResult;
            string strMaand, strDag, strJaar, strDatum;

            strMaand = Convert.ToString(item.geboorte.Month);
            strDag = Convert.ToString(item.geboorte.Day);
            strJaar = Convert.ToString(item.geboorte.Year);
            strDatum = strJaar + "-" + strMaand + "-" + strDag;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into leerling(naam,voornaam,geboortedatum,studierichting,bijknaam,gsm,geboorteplaats,nationaliteit,rijksrigister, straat, huisnummer, bus, land, postcode, email) values ('" +
                item.naam + "','" + item.voornaam + "','" + strDatum + "','" + item.studierichting + "','" + item.bijkomendenaam + "','"+ item.gsm + "','" + item.geboorteplaats + "','" + item.nationaliteit + "','" + item.rijksregister + "', '" + item.Straat + "', '" + item.Huisnummer + "', '" 
                + item.Bus + "', '" + item.Land + "', '" + item.Postcode + "', '" + item.Email + "')" , conn);

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;
        }

        public int AddGezin(Gezin item)
        {
            int intResult;
            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gezin(DomicilieTel,OudersGSM,EmailOuders,DomicilGSM) values ('"
                + item.DomicilieTel + "','" + item.OudersGSM + "','" + item.EmailOuders + "','" + item.DomicilieGSM + "')", conn);

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;
        }

        public int AddMoeder(Gezinslid item)
        {
            int intResult;
            string strMaand, strDag, strJaar, strDatum;

            strMaand = Convert.ToString(item.GeboorteDatum.Month);
            strDag = Convert.ToString(item.GeboorteDatum.Day);
            strJaar = Convert.ToString(item.GeboorteDatum.Year);
            strDatum = strJaar + "-" + strMaand + "-" + strDag;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gezinslid(naam,Voornaam,Gsm,Beroep,WerkTel,Rijksregisternr,Email,GeboorteDatum) values ('"
                + item.Naam + "','" + item.Voornaam + "','" + item.Gsm + "','" + item.Beroep + "','" + item.Rijksregisternr + "','" + item.WerkTel + "','" + item.Email + "','" + strDatum + "')", conn);

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;

        }

        public int AddVader(Gezinslid item)
        {
            int intResult;
            string strMaand, strDag, strJaar, strDatum;

            strMaand = Convert.ToString(item.GeboorteDatum.Month);
            strDag = Convert.ToString(item.GeboorteDatum.Day);
            strJaar = Convert.ToString(item.GeboorteDatum.Year);
            strDatum = strJaar + "-" + strMaand + "-" + strDag;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gezinslid(naam,Voornaam,Gsm,Beroep,WerkTel,Rijksregisternr,Email,GeboorteDatum) values ('"
                + item.Naam + "','" + item.Voornaam + "','" + item.Gsm + "','" + item.Beroep + "','" + item.WerkTel + "','" + item.Rijksregisternr + "','" + item.Email + "','" + strDatum + "')", conn);
            
            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;

        }

        public int AddStiefMoeder(Gezinslid item)
        {
            int intResult;
            string strMaand, strDag, strJaar, strDatum;

            strMaand = Convert.ToString(item.GeboorteDatum.Month);
            strDag = Convert.ToString(item.GeboorteDatum.Day);
            strJaar = Convert.ToString(item.GeboorteDatum.Year);
            strDatum = strJaar + "-" + strMaand + "-" + strDag;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gezinslid(naam,Voornaam,Gsm,Beroep,Rijksregisternr,Email,GeboorteDatum) values ('"
                + item.Naam + "','" + item.Voornaam + "','" + item.Gsm + "','" + item.Beroep + "','" + item.Rijksregisternr + "','" + item.Email + "','" + strDatum + "')", conn);
            
            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;
        }

        public int AddStiefVader(Gezinslid item)
        {
            int intResult;
            string strMaand, strDag, strJaar, strDatum;

            strMaand = Convert.ToString(item.GeboorteDatum.Month);
            strDag = Convert.ToString(item.GeboorteDatum.Day);
            strJaar = Convert.ToString(item.GeboorteDatum.Year);
            strDatum = strJaar + "-" + strMaand + "-" + strDag;

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into gezinslid(naam,Voornaam,Gsm,Beroep,Rijksregisternr,Email,GeboorteDatum) values ('"
                + item.Naam + "','" + item.Voornaam + "','" + item.Gsm + "','" + item.Beroep + "','" + item.Rijksregisternr + "','" + item.Email + "','" + strDatum + "')" , conn);

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;
        }

        public int Addinschrijving(Inschrijving item)
        {
            int intResult;
            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("insert into inschrijving(Aanmeldingstijd,tijd) values ('" + item.Aanmeldingstijd + " ',' " + item.Time + "')", conn);

            conn.Open();
            intResult = cmd.ExecuteNonQuery();
            conn.Close();

            return intResult;
        }

        public List<gemeente> getGemeente()
        {
            List<gemeente> list = new List<gemeente>();
            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("select * from gemeenten", conn);

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                gemeente gem = new gemeente(Convert.ToString(reader["Naam"]), Convert.ToString(reader["PostCode"]));
                list.Add(gem);
            }
            

            conn.Close();
            return list;
        }

        public List<Nationaliteit> getNationaliteit()
        {
            List<Nationaliteit> list = new List<Nationaliteit>();

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("select * from nationaliteit", conn);

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Nationaliteit nat = new Nationaliteit(Convert.ToString(reader["nationaliteit"]));
                list.Add(nat);
            }

            conn.Close();
            return list;
        }

        public List<Land> getLand()
        {
            List<Land> list = new List<Land>();

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("select * from landen", conn);

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Land nLand = new Land(Convert.ToString(reader["naam"]));
                list.Add(nLand);
            }

            conn.Close();
            return list;

        }

        public List<richting> getRichting()
        {
            List<richting> list = new List<richting>();

            MySqlConnection conn = new MySqlConnection(_connection);
            MySqlCommand cmd = new MySqlCommand("select * from richtingen", conn);

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                richting nRichting = new richting(Convert.ToString(reader["richtingen"]));
                list.Add(nRichting);
            }

            conn.Close();
            return list;

        }


    }
}
