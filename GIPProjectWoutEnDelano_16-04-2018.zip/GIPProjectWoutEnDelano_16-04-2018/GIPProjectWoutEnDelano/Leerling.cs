﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Leerling
    {
        private string strNaam, strVoorNaam, strStudierichting, strBijkNaam, strGeboorteplaats, strNationaliteit;
        private DateTime dteGeboorte;
        private string strgsm, strrijksregister, strGeslacht,strEmail, strStraat, strHuisnummer, strBus, strPostcode, strLand;

        public string Land
        {
            get { return strLand; }
            set { strLand = value; }
        }

        public string Postcode
        {
            get { return strPostcode; }
            set { strPostcode = value; }
        }

        public string Bus
        {
            get { return strBus; }
            set { strBus = value; }
        }

        public string Straat
        {
            get { return strStraat; }
            set { strStraat = value; }
        }

        public string Huisnummer
        {
            get { return strHuisnummer; }
            set { strHuisnummer = value; }
        }


        public string Email
        {
            get { return strEmail; }
            set { strEmail = value; }
        }

        public string rijksregister
        {
            get { return strrijksregister; }
            set { strrijksregister = value; }
        }

        public string Geslacht
        {
            get { return strGeslacht; }
            set { strGeslacht = value; }
        }

        public string gsm
        {
            get { return strgsm; }
            set { strgsm = value; }
        }

        public string naam
        {
            get { return strNaam; }
            set { strNaam = value; }
        }

        public string voornaam
        {
            get { return strVoorNaam; }
            set { strVoorNaam = value; }
        }

        public string nationaliteit
        {
            get { return strNationaliteit; }
            set { strNationaliteit = value; }
        }

        public string bijkomendenaam
        {
            get { return strBijkNaam; }
            set { strBijkNaam = value; }
        }

        public string geboorteplaats
        {
            get { return strGeboorteplaats; }
            set { strGeboorteplaats = value; }
        }


        public DateTime geboorte
        {
            get { return dteGeboorte; }
            set { dteGeboorte = value; }
        }
        

        public string studierichting
        {
            get { return strStudierichting; }
            set { strStudierichting = value; }
        }
       

        public Leerling() { }

        public Leerling(string pnaam, string pVoorNaam,DateTime pgeboorte, string pStudie, string pBijkNaam, string pGsm, string pGeboorteplaats, string pNationaliteit, string pRijksregister,string pGeslacht,string pEmail, string pStraat, string pstrHuisnummer, string pstrBus, string pstrLand, string pstrPostcode)
        {
            strNaam = pnaam;
            strVoorNaam = pVoorNaam;
            dteGeboorte = pgeboorte;
            strStudierichting = pStudie;
            strBijkNaam = pBijkNaam;
            strgsm = pGsm;
            strGeboorteplaats = pGeboorteplaats;
            strNationaliteit = pNationaliteit;
            strrijksregister = pRijksregister;
            strGeslacht = pGeslacht;
            strEmail = pEmail;
            strStraat = pStraat;
            strHuisnummer = pstrHuisnummer;
            strBus = pstrBus;
            strPostcode = pstrPostcode;
            strLand = pstrLand;
        }

    }
}
