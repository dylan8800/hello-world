﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class gemeente
    {
        private string strNaam;
        private string strPostcode;

        public string Naam
        {
            get { return strNaam; }
            set { strNaam = value; }
        }
        public string Postcode
        {
            get { return strPostcode; }
            set { strPostcode = value; }
        }

        public gemeente(string pstrNaam, string pstrPostcode)
        {
            strNaam = pstrNaam;
            strPostcode = pstrPostcode;
        }
    }
}
