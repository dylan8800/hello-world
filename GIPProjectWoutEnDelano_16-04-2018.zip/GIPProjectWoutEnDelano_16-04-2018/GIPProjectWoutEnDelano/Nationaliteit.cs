﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Nationaliteit
    {
        private string strNationaliteit;

        public string Nationality
        {
            get { return strNationaliteit; }
            set { strNationaliteit = value; }
        }

        public Nationaliteit(string pstrNationaliteit)
        {
            strNationaliteit = pstrNationaliteit;
        }
    }
}
