﻿namespace GIPProjectWoutEnDelano
{
    partial class inschrijvingsformulier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVoorNaam = new System.Windows.Forms.TextBox();
            this.lblLijn3 = new System.Windows.Forms.Label();
            this.lblLijn2 = new System.Windows.Forms.Label();
            this.lblLijn1 = new System.Windows.Forms.Label();
            this.txtGeboorteDatum = new System.Windows.Forms.MaskedTextBox();
            this.btnVoegToe = new System.Windows.Forms.Button();
            this.txtBijkVoorNamen = new System.Windows.Forms.TextBox();
            this.lblLijn5 = new System.Windows.Forms.Label();
            this.lblLijn4 = new System.Windows.Forms.Label();
            this.lblLijn6 = new System.Windows.Forms.Label();
            this.lblLijn7 = new System.Windows.Forms.Label();
            this.lblLijn8 = new System.Windows.Forms.Label();
            this.lblLijn9 = new System.Windows.Forms.Label();
            this.lblLijn10 = new System.Windows.Forms.Label();
            this.lblLijn11 = new System.Windows.Forms.Label();
            this.lblLijn12 = new System.Windows.Forms.Label();
            this.lblLijn13 = new System.Windows.Forms.Label();
            this.lblLijn14 = new System.Windows.Forms.Label();
            this.lblLijn15 = new System.Windows.Forms.Label();
            this.lblLijn16 = new System.Windows.Forms.Label();
            this.lblLijn17 = new System.Windows.Forms.Label();
            this.txtRijksregisternummer = new System.Windows.Forms.TextBox();
            this.txtHuisNummer = new System.Windows.Forms.TextBox();
            this.txtBus = new System.Windows.Forms.TextBox();
            this.txtGemeente = new System.Windows.Forms.TextBox();
            this.txtTelefoonDomicilie = new System.Windows.Forms.TextBox();
            this.txtgsmDomicilie = new System.Windows.Forms.TextBox();
            this.txtGsmEigen = new System.Windows.Forms.TextBox();
            this.txtStraat = new System.Windows.Forms.TextBox();
            this.txtNaam = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNaamMoeder = new System.Windows.Forms.TextBox();
            this.txtVoornaamMoeder = new System.Windows.Forms.TextBox();
            this.txtRijksregisterNummerMoeder = new System.Windows.Forms.TextBox();
            this.txtGSMmoeder = new System.Windows.Forms.TextBox();
            this.txtWerkTelMoeder = new System.Windows.Forms.TextBox();
            this.txtNaamVader = new System.Windows.Forms.TextBox();
            this.txtEmailMoeder = new System.Windows.Forms.TextBox();
            this.txtEmailOuders = new System.Windows.Forms.TextBox();
            this.txtEmailLeerling = new System.Windows.Forms.TextBox();
            this.txtGSMouders = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtVoornaamVader = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtBeroepStiefmoeder = new System.Windows.Forms.TextBox();
            this.txtGSMstiefmoeder = new System.Windows.Forms.TextBox();
            this.txtBeroepVader = new System.Windows.Forms.TextBox();
            this.txtGSMvader = new System.Windows.Forms.TextBox();
            this.txtWerkTelVader = new System.Windows.Forms.TextBox();
            this.txtEmailVader = new System.Windows.Forms.TextBox();
            this.txtNaamStiefvader = new System.Windows.Forms.TextBox();
            this.txtVoornaamStiefmoeder = new System.Windows.Forms.TextBox();
            this.txtNaamStiefmoeder = new System.Windows.Forms.TextBox();
            this.txtEmailStiefvader = new System.Windows.Forms.TextBox();
            this.txtGSMstiefvader = new System.Windows.Forms.TextBox();
            this.txtBeroepStiefVader = new System.Windows.Forms.TextBox();
            this.txtVoornaamStiefvader = new System.Windows.Forms.TextBox();
            this.txtRijksregisternummerVader = new System.Windows.Forms.TextBox();
            this.txtEmailStiefmoeder = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBeroepMoeder = new System.Windows.Forms.TextBox();
            this.txtGeboortedatumMAMS = new System.Windows.Forms.MaskedTextBox();
            this.txtGeboorteDatumPAPS = new System.Windows.Forms.MaskedTextBox();
            this.txtGeboorteDatumSPAPS = new System.Windows.Forms.MaskedTextBox();
            this.txtGeboorteDatumSMAMS = new System.Windows.Forms.MaskedTextBox();
            this.cboGeslacht = new System.Windows.Forms.ComboBox();
            this.cboGeboorte = new System.Windows.Forms.ComboBox();
            this.txtNationaliteit = new System.Windows.Forms.ComboBox();
            this.txtPostcode = new System.Windows.Forms.ComboBox();
            this.txtLand = new System.Windows.Forms.ComboBox();
            this.txtStudieKeuze = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtVoorNaam
            // 
            this.txtVoorNaam.Location = new System.Drawing.Point(120, 53);
            this.txtVoorNaam.Name = "txtVoorNaam";
            this.txtVoorNaam.Size = new System.Drawing.Size(100, 20);
            this.txtVoorNaam.TabIndex = 1;
            // 
            // lblLijn3
            // 
            this.lblLijn3.AutoSize = true;
            this.lblLijn3.Location = new System.Drawing.Point(18, 134);
            this.lblLijn3.Name = "lblLijn3";
            this.lblLijn3.Size = new System.Drawing.Size(80, 13);
            this.lblLijn3.TabIndex = 12;
            this.lblLijn3.Text = "Geboortedatum";
            // 
            // lblLijn2
            // 
            this.lblLijn2.AutoSize = true;
            this.lblLijn2.Location = new System.Drawing.Point(18, 56);
            this.lblLijn2.Name = "lblLijn2";
            this.lblLijn2.Size = new System.Drawing.Size(55, 13);
            this.lblLijn2.TabIndex = 11;
            this.lblLijn2.Text = "Voornaam";
            // 
            // lblLijn1
            // 
            this.lblLijn1.AutoSize = true;
            this.lblLijn1.Location = new System.Drawing.Point(18, 30);
            this.lblLijn1.Name = "lblLijn1";
            this.lblLijn1.Size = new System.Drawing.Size(35, 13);
            this.lblLijn1.TabIndex = 10;
            this.lblLijn1.Text = "Naam";
            // 
            // txtGeboorteDatum
            // 
            this.txtGeboorteDatum.Location = new System.Drawing.Point(120, 131);
            this.txtGeboorteDatum.Mask = "00/00/0000";
            this.txtGeboorteDatum.Name = "txtGeboorteDatum";
            this.txtGeboorteDatum.Size = new System.Drawing.Size(62, 20);
            this.txtGeboorteDatum.TabIndex = 4;
            this.txtGeboorteDatum.ValidatingType = typeof(System.DateTime);
            // 
            // btnVoegToe
            // 
            this.btnVoegToe.Location = new System.Drawing.Point(810, 364);
            this.btnVoegToe.Name = "btnVoegToe";
            this.btnVoegToe.Size = new System.Drawing.Size(75, 23);
            this.btnVoegToe.TabIndex = 49;
            this.btnVoegToe.Text = "Voeg toe ";
            this.btnVoegToe.UseVisualStyleBackColor = true;
            this.btnVoegToe.Click += new System.EventHandler(this.btnVoegToe_Click_1);
            // 
            // txtBijkVoorNamen
            // 
            this.txtBijkVoorNamen.Location = new System.Drawing.Point(120, 79);
            this.txtBijkVoorNamen.Name = "txtBijkVoorNamen";
            this.txtBijkVoorNamen.Size = new System.Drawing.Size(100, 20);
            this.txtBijkVoorNamen.TabIndex = 2;
            this.txtBijkVoorNamen.TextChanged += new System.EventHandler(this.txtBijkVoorNamen_TextChanged);
            // 
            // lblLijn5
            // 
            this.lblLijn5.AutoSize = true;
            this.lblLijn5.Location = new System.Drawing.Point(18, 108);
            this.lblLijn5.Name = "lblLijn5";
            this.lblLijn5.Size = new System.Drawing.Size(49, 13);
            this.lblLijn5.TabIndex = 20;
            this.lblLijn5.Text = "Geslacht";
            // 
            // lblLijn4
            // 
            this.lblLijn4.AutoSize = true;
            this.lblLijn4.Location = new System.Drawing.Point(18, 82);
            this.lblLijn4.Name = "lblLijn4";
            this.lblLijn4.Size = new System.Drawing.Size(80, 13);
            this.lblLijn4.TabIndex = 21;
            this.lblLijn4.Text = "Bijk voornamen";
            // 
            // lblLijn6
            // 
            this.lblLijn6.AutoSize = true;
            this.lblLijn6.Location = new System.Drawing.Point(18, 160);
            this.lblLijn6.Name = "lblLijn6";
            this.lblLijn6.Size = new System.Drawing.Size(79, 13);
            this.lblLijn6.TabIndex = 22;
            this.lblLijn6.Text = "Geboorteplaats";
            // 
            // lblLijn7
            // 
            this.lblLijn7.AutoSize = true;
            this.lblLijn7.Location = new System.Drawing.Point(18, 186);
            this.lblLijn7.Name = "lblLijn7";
            this.lblLijn7.Size = new System.Drawing.Size(101, 13);
            this.lblLijn7.TabIndex = 23;
            this.lblLijn7.Text = "Rijksregisternummer";
            // 
            // lblLijn8
            // 
            this.lblLijn8.AutoSize = true;
            this.lblLijn8.Location = new System.Drawing.Point(18, 212);
            this.lblLijn8.Name = "lblLijn8";
            this.lblLijn8.Size = new System.Drawing.Size(35, 13);
            this.lblLijn8.TabIndex = 24;
            this.lblLijn8.Text = "Straat";
            // 
            // lblLijn9
            // 
            this.lblLijn9.AutoSize = true;
            this.lblLijn9.Location = new System.Drawing.Point(18, 238);
            this.lblLijn9.Name = "lblLijn9";
            this.lblLijn9.Size = new System.Drawing.Size(65, 13);
            this.lblLijn9.TabIndex = 25;
            this.lblLijn9.Text = "Huisnummer";
            // 
            // lblLijn10
            // 
            this.lblLijn10.AutoSize = true;
            this.lblLijn10.Location = new System.Drawing.Point(18, 264);
            this.lblLijn10.Name = "lblLijn10";
            this.lblLijn10.Size = new System.Drawing.Size(25, 13);
            this.lblLijn10.TabIndex = 26;
            this.lblLijn10.Text = "Bus";
            // 
            // lblLijn11
            // 
            this.lblLijn11.AutoSize = true;
            this.lblLijn11.Location = new System.Drawing.Point(251, 30);
            this.lblLijn11.Name = "lblLijn11";
            this.lblLijn11.Size = new System.Drawing.Size(52, 13);
            this.lblLijn11.TabIndex = 27;
            this.lblLijn11.Text = "Postcode";
            // 
            // lblLijn12
            // 
            this.lblLijn12.AutoSize = true;
            this.lblLijn12.Location = new System.Drawing.Point(251, 56);
            this.lblLijn12.Name = "lblLijn12";
            this.lblLijn12.Size = new System.Drawing.Size(56, 13);
            this.lblLijn12.TabIndex = 28;
            this.lblLijn12.Text = "Gemeente";
            // 
            // lblLijn13
            // 
            this.lblLijn13.AutoSize = true;
            this.lblLijn13.Location = new System.Drawing.Point(251, 82);
            this.lblLijn13.Name = "lblLijn13";
            this.lblLijn13.Size = new System.Drawing.Size(31, 13);
            this.lblLijn13.TabIndex = 29;
            this.lblLijn13.Text = "Land";
            // 
            // lblLijn14
            // 
            this.lblLijn14.AutoSize = true;
            this.lblLijn14.Location = new System.Drawing.Point(251, 108);
            this.lblLijn14.Name = "lblLijn14";
            this.lblLijn14.Size = new System.Drawing.Size(62, 13);
            this.lblLijn14.TabIndex = 30;
            this.lblLijn14.Text = "Nationaliteit";
            // 
            // lblLijn15
            // 
            this.lblLijn15.AutoSize = true;
            this.lblLijn15.Location = new System.Drawing.Point(251, 134);
            this.lblLijn15.Name = "lblLijn15";
            this.lblLijn15.Size = new System.Drawing.Size(92, 13);
            this.lblLijn15.TabIndex = 31;
            this.lblLijn15.Text = "Telefoon domicilie";
            // 
            // lblLijn16
            // 
            this.lblLijn16.AutoSize = true;
            this.lblLijn16.Location = new System.Drawing.Point(251, 160);
            this.lblLijn16.Name = "lblLijn16";
            this.lblLijn16.Size = new System.Drawing.Size(74, 13);
            this.lblLijn16.TabIndex = 32;
            this.lblLijn16.Text = "GSM domicilie";
            // 
            // lblLijn17
            // 
            this.lblLijn17.AutoSize = true;
            this.lblLijn17.Location = new System.Drawing.Point(251, 186);
            this.lblLijn17.Name = "lblLijn17";
            this.lblLijn17.Size = new System.Drawing.Size(71, 13);
            this.lblLijn17.TabIndex = 33;
            this.lblLijn17.Text = "GSM Leerling";
            // 
            // txtRijksregisternummer
            // 
            this.txtRijksregisternummer.Location = new System.Drawing.Point(120, 183);
            this.txtRijksregisternummer.Name = "txtRijksregisternummer";
            this.txtRijksregisternummer.Size = new System.Drawing.Size(100, 20);
            this.txtRijksregisternummer.TabIndex = 6;
            // 
            // txtHuisNummer
            // 
            this.txtHuisNummer.Location = new System.Drawing.Point(120, 235);
            this.txtHuisNummer.Name = "txtHuisNummer";
            this.txtHuisNummer.Size = new System.Drawing.Size(100, 20);
            this.txtHuisNummer.TabIndex = 8;
            // 
            // txtBus
            // 
            this.txtBus.Location = new System.Drawing.Point(120, 261);
            this.txtBus.Name = "txtBus";
            this.txtBus.Size = new System.Drawing.Size(100, 20);
            this.txtBus.TabIndex = 9;
            this.txtBus.TextChanged += new System.EventHandler(this.txtBus_TextChanged);
            // 
            // txtGemeente
            // 
            this.txtGemeente.Location = new System.Drawing.Point(353, 53);
            this.txtGemeente.Name = "txtGemeente";
            this.txtGemeente.Size = new System.Drawing.Size(100, 20);
            this.txtGemeente.TabIndex = 11;
            // 
            // txtTelefoonDomicilie
            // 
            this.txtTelefoonDomicilie.Location = new System.Drawing.Point(353, 131);
            this.txtTelefoonDomicilie.Name = "txtTelefoonDomicilie";
            this.txtTelefoonDomicilie.Size = new System.Drawing.Size(100, 20);
            this.txtTelefoonDomicilie.TabIndex = 14;
            // 
            // txtgsmDomicilie
            // 
            this.txtgsmDomicilie.Location = new System.Drawing.Point(353, 157);
            this.txtgsmDomicilie.Name = "txtgsmDomicilie";
            this.txtgsmDomicilie.Size = new System.Drawing.Size(100, 20);
            this.txtgsmDomicilie.TabIndex = 15;
            // 
            // txtGsmEigen
            // 
            this.txtGsmEigen.Location = new System.Drawing.Point(353, 183);
            this.txtGsmEigen.Name = "txtGsmEigen";
            this.txtGsmEigen.Size = new System.Drawing.Size(100, 20);
            this.txtGsmEigen.TabIndex = 16;
            // 
            // txtStraat
            // 
            this.txtStraat.Location = new System.Drawing.Point(120, 209);
            this.txtStraat.Name = "txtStraat";
            this.txtStraat.Size = new System.Drawing.Size(100, 20);
            this.txtStraat.TabIndex = 7;
            this.txtStraat.TextChanged += new System.EventHandler(this.txtStraat_TextChanged);
            // 
            // txtNaam
            // 
            this.txtNaam.Location = new System.Drawing.Point(120, 28);
            this.txtNaam.Name = "txtNaam";
            this.txtNaam.Size = new System.Drawing.Size(100, 20);
            this.txtNaam.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(251, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 47;
            this.label1.Text = "GSM ouders";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(284, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 48;
            this.label2.Text = "Naam vader";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 49;
            this.label3.Text = "E-mail moeder";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 50;
            this.label4.Text = "Telefoon werk moeder";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 51;
            this.label5.Text = "GSM Moeder";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 13);
            this.label6.TabIndex = 52;
            this.label6.Text = "Rijksregisternummer moeder";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 13);
            this.label7.TabIndex = 53;
            this.label7.Text = "geboortedatum moeder";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 13);
            this.label8.TabIndex = 54;
            this.label8.Text = "Voornaam Moeder";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 55;
            this.label9.Text = "Naam Moeder";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(251, 264);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 13);
            this.label10.TabIndex = 56;
            this.label10.Text = "Studie keuze";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(21, 280);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 58;
            this.label12.Text = "E-mail ouders";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(251, 238);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "E-mail Leerling";
            // 
            // txtNaamMoeder
            // 
            this.txtNaamMoeder.Location = new System.Drawing.Point(163, 27);
            this.txtNaamMoeder.Name = "txtNaamMoeder";
            this.txtNaamMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtNaamMoeder.TabIndex = 21;
            // 
            // txtVoornaamMoeder
            // 
            this.txtVoornaamMoeder.Location = new System.Drawing.Point(163, 53);
            this.txtVoornaamMoeder.Name = "txtVoornaamMoeder";
            this.txtVoornaamMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtVoornaamMoeder.TabIndex = 22;
            // 
            // txtRijksregisterNummerMoeder
            // 
            this.txtRijksregisterNummerMoeder.Location = new System.Drawing.Point(163, 105);
            this.txtRijksregisterNummerMoeder.Name = "txtRijksregisterNummerMoeder";
            this.txtRijksregisterNummerMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtRijksregisterNummerMoeder.TabIndex = 24;
            // 
            // txtGSMmoeder
            // 
            this.txtGSMmoeder.Location = new System.Drawing.Point(163, 157);
            this.txtGSMmoeder.Name = "txtGSMmoeder";
            this.txtGSMmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtGSMmoeder.TabIndex = 26;
            // 
            // txtWerkTelMoeder
            // 
            this.txtWerkTelMoeder.Location = new System.Drawing.Point(163, 183);
            this.txtWerkTelMoeder.Name = "txtWerkTelMoeder";
            this.txtWerkTelMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtWerkTelMoeder.TabIndex = 27;
            // 
            // txtNaamVader
            // 
            this.txtNaamVader.Location = new System.Drawing.Point(426, 28);
            this.txtNaamVader.Name = "txtNaamVader";
            this.txtNaamVader.Size = new System.Drawing.Size(100, 20);
            this.txtNaamVader.TabIndex = 29;
            // 
            // txtEmailMoeder
            // 
            this.txtEmailMoeder.Location = new System.Drawing.Point(163, 209);
            this.txtEmailMoeder.Name = "txtEmailMoeder";
            this.txtEmailMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtEmailMoeder.TabIndex = 28;
            // 
            // txtEmailOuders
            // 
            this.txtEmailOuders.Location = new System.Drawing.Point(163, 277);
            this.txtEmailOuders.Name = "txtEmailOuders";
            this.txtEmailOuders.Size = new System.Drawing.Size(100, 20);
            this.txtEmailOuders.TabIndex = 19;
            // 
            // txtEmailLeerling
            // 
            this.txtEmailLeerling.Location = new System.Drawing.Point(353, 235);
            this.txtEmailLeerling.Name = "txtEmailLeerling";
            this.txtEmailLeerling.Size = new System.Drawing.Size(100, 20);
            this.txtEmailLeerling.TabIndex = 18;
            // 
            // txtGSMouders
            // 
            this.txtGSMouders.Location = new System.Drawing.Point(353, 209);
            this.txtGSMouders.Name = "txtGSMouders";
            this.txtGSMouders.Size = new System.Drawing.Size(100, 20);
            this.txtGSMouders.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(284, 83);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 13);
            this.label14.TabIndex = 73;
            this.label14.Text = "Geboortedatum vader";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(284, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 13);
            this.label15.TabIndex = 74;
            this.label15.Text = "Voornaam vader";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(284, 134);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 13);
            this.label16.TabIndex = 75;
            this.label16.Text = "Beroep vader";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(284, 160);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 13);
            this.label17.TabIndex = 76;
            this.label17.Text = "GSM vader";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(284, 186);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(105, 13);
            this.label18.TabIndex = 77;
            this.label18.Text = "Telefoon werk vader";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(284, 212);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 13);
            this.label19.TabIndex = 78;
            this.label19.Text = "E-mail vader";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 29);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 13);
            this.label20.TabIndex = 79;
            this.label20.Text = "Naam stiefvader";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 55);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(104, 13);
            this.label21.TabIndex = 80;
            this.label21.Text = "Voornaam stiefvader";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 81);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(129, 13);
            this.label22.TabIndex = 81;
            this.label22.Text = "Geboortedatum stiefvader";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 107);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 13);
            this.label23.TabIndex = 82;
            this.label23.Text = "Beroep stiefvader";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 133);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(80, 13);
            this.label24.TabIndex = 83;
            this.label24.Text = "GSM stiefvader";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 159);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(84, 13);
            this.label25.TabIndex = 84;
            this.label25.Text = "E-mail stiefvader";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(293, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 13);
            this.label26.TabIndex = 85;
            this.label26.Text = "Naam stiefmoeder";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(293, 55);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(112, 13);
            this.label27.TabIndex = 86;
            this.label27.Text = "Voornaam stiefmoeder";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(284, 108);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(134, 13);
            this.label28.TabIndex = 87;
            this.label28.Text = "Rijksregister nummer vader";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(293, 133);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(88, 13);
            this.label29.TabIndex = 88;
            this.label29.Text = "GSM stiefmoeder";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(293, 107);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 13);
            this.label30.TabIndex = 89;
            this.label30.Text = "Beroep stiefmoeder";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(293, 81);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(137, 13);
            this.label31.TabIndex = 90;
            this.label31.Text = "Geboortedatum stiefmoeder";
            // 
            // txtVoornaamVader
            // 
            this.txtVoornaamVader.Location = new System.Drawing.Point(426, 54);
            this.txtVoornaamVader.Name = "txtVoornaamVader";
            this.txtVoornaamVader.Size = new System.Drawing.Size(100, 20);
            this.txtVoornaamVader.TabIndex = 30;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(293, 159);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(92, 13);
            this.label36.TabIndex = 108;
            this.label36.Text = "E-mail stiefmoeder";
            // 
            // txtBeroepStiefmoeder
            // 
            this.txtBeroepStiefmoeder.Location = new System.Drawing.Point(440, 104);
            this.txtBeroepStiefmoeder.Name = "txtBeroepStiefmoeder";
            this.txtBeroepStiefmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtBeroepStiefmoeder.TabIndex = 46;
            // 
            // txtGSMstiefmoeder
            // 
            this.txtGSMstiefmoeder.Location = new System.Drawing.Point(440, 130);
            this.txtGSMstiefmoeder.Name = "txtGSMstiefmoeder";
            this.txtGSMstiefmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtGSMstiefmoeder.TabIndex = 47;
            // 
            // txtBeroepVader
            // 
            this.txtBeroepVader.Location = new System.Drawing.Point(426, 131);
            this.txtBeroepVader.Name = "txtBeroepVader";
            this.txtBeroepVader.Size = new System.Drawing.Size(100, 20);
            this.txtBeroepVader.TabIndex = 33;
            // 
            // txtGSMvader
            // 
            this.txtGSMvader.Location = new System.Drawing.Point(426, 157);
            this.txtGSMvader.Name = "txtGSMvader";
            this.txtGSMvader.Size = new System.Drawing.Size(100, 20);
            this.txtGSMvader.TabIndex = 34;
            // 
            // txtWerkTelVader
            // 
            this.txtWerkTelVader.Location = new System.Drawing.Point(426, 183);
            this.txtWerkTelVader.Name = "txtWerkTelVader";
            this.txtWerkTelVader.Size = new System.Drawing.Size(100, 20);
            this.txtWerkTelVader.TabIndex = 35;
            // 
            // txtEmailVader
            // 
            this.txtEmailVader.Location = new System.Drawing.Point(426, 209);
            this.txtEmailVader.Name = "txtEmailVader";
            this.txtEmailVader.Size = new System.Drawing.Size(100, 20);
            this.txtEmailVader.TabIndex = 36;
            // 
            // txtNaamStiefvader
            // 
            this.txtNaamStiefvader.Location = new System.Drawing.Point(157, 26);
            this.txtNaamStiefvader.Name = "txtNaamStiefvader";
            this.txtNaamStiefvader.Size = new System.Drawing.Size(100, 20);
            this.txtNaamStiefvader.TabIndex = 37;
            // 
            // txtVoornaamStiefmoeder
            // 
            this.txtVoornaamStiefmoeder.Location = new System.Drawing.Point(440, 52);
            this.txtVoornaamStiefmoeder.Name = "txtVoornaamStiefmoeder";
            this.txtVoornaamStiefmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtVoornaamStiefmoeder.TabIndex = 44;
            // 
            // txtNaamStiefmoeder
            // 
            this.txtNaamStiefmoeder.Location = new System.Drawing.Point(440, 26);
            this.txtNaamStiefmoeder.Name = "txtNaamStiefmoeder";
            this.txtNaamStiefmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtNaamStiefmoeder.TabIndex = 43;
            // 
            // txtEmailStiefvader
            // 
            this.txtEmailStiefvader.Location = new System.Drawing.Point(157, 156);
            this.txtEmailStiefvader.Name = "txtEmailStiefvader";
            this.txtEmailStiefvader.Size = new System.Drawing.Size(100, 20);
            this.txtEmailStiefvader.TabIndex = 42;
            this.txtEmailStiefvader.TextChanged += new System.EventHandler(this.txtEmailStiefvader_TextChanged);
            // 
            // txtGSMstiefvader
            // 
            this.txtGSMstiefvader.Location = new System.Drawing.Point(157, 130);
            this.txtGSMstiefvader.Name = "txtGSMstiefvader";
            this.txtGSMstiefvader.Size = new System.Drawing.Size(100, 20);
            this.txtGSMstiefvader.TabIndex = 41;
            // 
            // txtBeroepStiefVader
            // 
            this.txtBeroepStiefVader.Location = new System.Drawing.Point(157, 104);
            this.txtBeroepStiefVader.Name = "txtBeroepStiefVader";
            this.txtBeroepStiefVader.Size = new System.Drawing.Size(100, 20);
            this.txtBeroepStiefVader.TabIndex = 40;
            // 
            // txtVoornaamStiefvader
            // 
            this.txtVoornaamStiefvader.Location = new System.Drawing.Point(157, 52);
            this.txtVoornaamStiefvader.Name = "txtVoornaamStiefvader";
            this.txtVoornaamStiefvader.Size = new System.Drawing.Size(100, 20);
            this.txtVoornaamStiefvader.TabIndex = 38;
            // 
            // txtRijksregisternummerVader
            // 
            this.txtRijksregisternummerVader.Location = new System.Drawing.Point(426, 105);
            this.txtRijksregisternummerVader.Name = "txtRijksregisternummerVader";
            this.txtRijksregisternummerVader.Size = new System.Drawing.Size(100, 20);
            this.txtRijksregisternummerVader.TabIndex = 32;
            // 
            // txtEmailStiefmoeder
            // 
            this.txtEmailStiefmoeder.Location = new System.Drawing.Point(440, 156);
            this.txtEmailStiefmoeder.Name = "txtEmailStiefmoeder";
            this.txtEmailStiefmoeder.Size = new System.Drawing.Size(100, 20);
            this.txtEmailStiefmoeder.TabIndex = 48;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 134);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 129;
            this.label11.Text = "beroep moeder";
            // 
            // txtBeroepMoeder
            // 
            this.txtBeroepMoeder.Location = new System.Drawing.Point(163, 131);
            this.txtBeroepMoeder.Name = "txtBeroepMoeder";
            this.txtBeroepMoeder.Size = new System.Drawing.Size(100, 20);
            this.txtBeroepMoeder.TabIndex = 25;
            // 
            // txtGeboortedatumMAMS
            // 
            this.txtGeboortedatumMAMS.Location = new System.Drawing.Point(163, 79);
            this.txtGeboortedatumMAMS.Mask = "00/00/0000";
            this.txtGeboortedatumMAMS.Name = "txtGeboortedatumMAMS";
            this.txtGeboortedatumMAMS.Size = new System.Drawing.Size(63, 20);
            this.txtGeboortedatumMAMS.TabIndex = 23;
            this.txtGeboortedatumMAMS.ValidatingType = typeof(System.DateTime);
            // 
            // txtGeboorteDatumPAPS
            // 
            this.txtGeboorteDatumPAPS.Location = new System.Drawing.Point(426, 80);
            this.txtGeboorteDatumPAPS.Mask = "00/00/0000";
            this.txtGeboorteDatumPAPS.Name = "txtGeboorteDatumPAPS";
            this.txtGeboorteDatumPAPS.Size = new System.Drawing.Size(100, 20);
            this.txtGeboorteDatumPAPS.TabIndex = 31;
            this.txtGeboorteDatumPAPS.ValidatingType = typeof(System.DateTime);
            // 
            // txtGeboorteDatumSPAPS
            // 
            this.txtGeboorteDatumSPAPS.Location = new System.Drawing.Point(157, 78);
            this.txtGeboorteDatumSPAPS.Mask = "00/00/0000";
            this.txtGeboorteDatumSPAPS.Name = "txtGeboorteDatumSPAPS";
            this.txtGeboorteDatumSPAPS.Size = new System.Drawing.Size(100, 20);
            this.txtGeboorteDatumSPAPS.TabIndex = 39;
            this.txtGeboorteDatumSPAPS.ValidatingType = typeof(System.DateTime);
            // 
            // txtGeboorteDatumSMAMS
            // 
            this.txtGeboorteDatumSMAMS.Location = new System.Drawing.Point(440, 78);
            this.txtGeboorteDatumSMAMS.Mask = "00/00/0000";
            this.txtGeboorteDatumSMAMS.Name = "txtGeboorteDatumSMAMS";
            this.txtGeboorteDatumSMAMS.Size = new System.Drawing.Size(100, 20);
            this.txtGeboorteDatumSMAMS.TabIndex = 45;
            this.txtGeboorteDatumSMAMS.ValidatingType = typeof(System.DateTime);
            // 
            // cboGeslacht
            // 
            this.cboGeslacht.FormattingEnabled = true;
            this.cboGeslacht.Items.AddRange(new object[] {
            "Man",
            "Vrouw"});
            this.cboGeslacht.Location = new System.Drawing.Point(120, 105);
            this.cboGeslacht.Name = "cboGeslacht";
            this.cboGeslacht.Size = new System.Drawing.Size(100, 21);
            this.cboGeslacht.TabIndex = 3;
            // 
            // cboGeboorte
            // 
            this.cboGeboorte.FormattingEnabled = true;
            this.cboGeboorte.Location = new System.Drawing.Point(120, 157);
            this.cboGeboorte.Name = "cboGeboorte";
            this.cboGeboorte.Size = new System.Drawing.Size(100, 21);
            this.cboGeboorte.TabIndex = 5;
            this.cboGeboorte.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtNationaliteit
            // 
            this.txtNationaliteit.FormattingEnabled = true;
            this.txtNationaliteit.Location = new System.Drawing.Point(353, 104);
            this.txtNationaliteit.Name = "txtNationaliteit";
            this.txtNationaliteit.Size = new System.Drawing.Size(100, 21);
            this.txtNationaliteit.TabIndex = 13;
            // 
            // txtPostcode
            // 
            this.txtPostcode.FormattingEnabled = true;
            this.txtPostcode.Location = new System.Drawing.Point(353, 26);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(100, 21);
            this.txtPostcode.TabIndex = 10;
            // 
            // txtLand
            // 
            this.txtLand.FormattingEnabled = true;
            this.txtLand.Location = new System.Drawing.Point(353, 78);
            this.txtLand.Name = "txtLand";
            this.txtLand.Size = new System.Drawing.Size(100, 21);
            this.txtLand.TabIndex = 12;
            // 
            // txtStudieKeuze
            // 
            this.txtStudieKeuze.FormattingEnabled = true;
            this.txtStudieKeuze.Location = new System.Drawing.Point(353, 261);
            this.txtStudieKeuze.Name = "txtStudieKeuze";
            this.txtStudieKeuze.Size = new System.Drawing.Size(100, 21);
            this.txtStudieKeuze.TabIndex = 20;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblLijn1);
            this.groupBox1.Controls.Add(this.txtStudieKeuze);
            this.groupBox1.Controls.Add(this.lblLijn2);
            this.groupBox1.Controls.Add(this.txtLand);
            this.groupBox1.Controls.Add(this.lblLijn3);
            this.groupBox1.Controls.Add(this.txtPostcode);
            this.groupBox1.Controls.Add(this.txtVoorNaam);
            this.groupBox1.Controls.Add(this.txtNationaliteit);
            this.groupBox1.Controls.Add(this.txtGeboorteDatum);
            this.groupBox1.Controls.Add(this.cboGeboorte);
            this.groupBox1.Controls.Add(this.txtBijkVoorNamen);
            this.groupBox1.Controls.Add(this.cboGeslacht);
            this.groupBox1.Controls.Add(this.lblLijn5);
            this.groupBox1.Controls.Add(this.lblLijn4);
            this.groupBox1.Controls.Add(this.lblLijn6);
            this.groupBox1.Controls.Add(this.lblLijn7);
            this.groupBox1.Controls.Add(this.lblLijn8);
            this.groupBox1.Controls.Add(this.lblLijn9);
            this.groupBox1.Controls.Add(this.lblLijn10);
            this.groupBox1.Controls.Add(this.lblLijn11);
            this.groupBox1.Controls.Add(this.lblLijn12);
            this.groupBox1.Controls.Add(this.lblLijn13);
            this.groupBox1.Controls.Add(this.lblLijn14);
            this.groupBox1.Controls.Add(this.lblLijn15);
            this.groupBox1.Controls.Add(this.lblLijn16);
            this.groupBox1.Controls.Add(this.lblLijn17);
            this.groupBox1.Controls.Add(this.txtRijksregisternummer);
            this.groupBox1.Controls.Add(this.txtHuisNummer);
            this.groupBox1.Controls.Add(this.txtBus);
            this.groupBox1.Controls.Add(this.txtGemeente);
            this.groupBox1.Controls.Add(this.txtTelefoonDomicilie);
            this.groupBox1.Controls.Add(this.txtgsmDomicilie);
            this.groupBox1.Controls.Add(this.txtGsmEigen);
            this.groupBox1.Controls.Add(this.txtStraat);
            this.groupBox1.Controls.Add(this.txtNaam);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtEmailLeerling);
            this.groupBox1.Controls.Add(this.txtGSMouders);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(485, 312);
            this.groupBox1.TabIndex = 130;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtEmailOuders);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtGeboorteDatumPAPS);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtGeboortedatumMAMS);
            this.groupBox2.Controls.Add(this.txtBeroepVader);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtGSMvader);
            this.groupBox2.Controls.Add(this.txtBeroepMoeder);
            this.groupBox2.Controls.Add(this.txtWerkTelVader);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtEmailVader);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtNaamMoeder);
            this.groupBox2.Controls.Add(this.txtVoornaamMoeder);
            this.groupBox2.Controls.Add(this.txtRijksregisterNummerMoeder);
            this.groupBox2.Controls.Add(this.txtGSMmoeder);
            this.groupBox2.Controls.Add(this.txtWerkTelMoeder);
            this.groupBox2.Controls.Add(this.txtRijksregisternummerVader);
            this.groupBox2.Controls.Add(this.txtEmailMoeder);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtNaamVader);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtVoornaamVader);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Location = new System.Drawing.Point(530, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(576, 312);
            this.groupBox2.TabIndex = 131;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.txtNaamStiefvader);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.txtGeboorteDatumSMAMS);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txtEmailStiefmoeder);
            this.groupBox3.Controls.Add(this.txtGeboorteDatumSPAPS);
            this.groupBox3.Controls.Add(this.txtBeroepStiefmoeder);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.txtGSMstiefmoeder);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.txtVoornaamStiefmoeder);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.txtNaamStiefmoeder);
            this.groupBox3.Controls.Add(this.txtVoornaamStiefvader);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.txtBeroepStiefVader);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.txtGSMstiefvader);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.txtEmailStiefvader);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Location = new System.Drawing.Point(13, 335);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(561, 212);
            this.groupBox3.TabIndex = 132;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(651, 413);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 133;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(909, 425);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 134;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(752, 499);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 135;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(880, 499);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 136;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(566, 364);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 137;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // inschrijvingsformulier
            // 
            this.AcceptButton = this.btnVoegToe;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(1124, 579);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnVoegToe);
            this.KeyPreview = true;
            this.Name = "inschrijvingsformulier";
            this.Text = "inschrijving";
            this.Load += new System.EventHandler(this.start_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtVoorNaam;
        private System.Windows.Forms.Label lblLijn3;
        private System.Windows.Forms.Label lblLijn2;
        private System.Windows.Forms.Label lblLijn1;
        private System.Windows.Forms.MaskedTextBox txtGeboorteDatum;
        private System.Windows.Forms.Button btnVoegToe;
        private System.Windows.Forms.TextBox txtBijkVoorNamen;
        private System.Windows.Forms.Label lblLijn5;
        private System.Windows.Forms.Label lblLijn4;
        private System.Windows.Forms.Label lblLijn6;
        private System.Windows.Forms.Label lblLijn7;
        private System.Windows.Forms.Label lblLijn8;
        private System.Windows.Forms.Label lblLijn9;
        private System.Windows.Forms.Label lblLijn10;
        private System.Windows.Forms.Label lblLijn11;
        private System.Windows.Forms.Label lblLijn12;
        private System.Windows.Forms.Label lblLijn13;
        private System.Windows.Forms.Label lblLijn14;
        private System.Windows.Forms.Label lblLijn15;
        private System.Windows.Forms.Label lblLijn16;
        private System.Windows.Forms.Label lblLijn17;
        private System.Windows.Forms.TextBox txtRijksregisternummer;
        private System.Windows.Forms.TextBox txtHuisNummer;
        private System.Windows.Forms.TextBox txtBus;
        private System.Windows.Forms.TextBox txtGemeente;
        private System.Windows.Forms.TextBox txtTelefoonDomicilie;
        private System.Windows.Forms.TextBox txtgsmDomicilie;
        private System.Windows.Forms.TextBox txtGsmEigen;
        private System.Windows.Forms.TextBox txtStraat;
        private System.Windows.Forms.TextBox txtNaam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNaamMoeder;
        private System.Windows.Forms.TextBox txtVoornaamMoeder;
        private System.Windows.Forms.TextBox txtRijksregisterNummerMoeder;
        private System.Windows.Forms.TextBox txtGSMmoeder;
        private System.Windows.Forms.TextBox txtWerkTelMoeder;
        private System.Windows.Forms.TextBox txtNaamVader;
        private System.Windows.Forms.TextBox txtEmailMoeder;
        private System.Windows.Forms.TextBox txtEmailOuders;
        private System.Windows.Forms.TextBox txtEmailLeerling;
        private System.Windows.Forms.TextBox txtGSMouders;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtVoornaamVader;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtBeroepStiefmoeder;
        private System.Windows.Forms.TextBox txtGSMstiefmoeder;
        private System.Windows.Forms.TextBox txtBeroepVader;
        private System.Windows.Forms.TextBox txtGSMvader;
        private System.Windows.Forms.TextBox txtWerkTelVader;
        private System.Windows.Forms.TextBox txtEmailVader;
        private System.Windows.Forms.TextBox txtNaamStiefvader;
        private System.Windows.Forms.TextBox txtVoornaamStiefmoeder;
        private System.Windows.Forms.TextBox txtNaamStiefmoeder;
        private System.Windows.Forms.TextBox txtEmailStiefvader;
        private System.Windows.Forms.TextBox txtGSMstiefvader;
        private System.Windows.Forms.TextBox txtBeroepStiefVader;
        private System.Windows.Forms.TextBox txtVoornaamStiefvader;
        private System.Windows.Forms.TextBox txtRijksregisternummerVader;
        private System.Windows.Forms.TextBox txtEmailStiefmoeder;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBeroepMoeder;
        private System.Windows.Forms.MaskedTextBox txtGeboortedatumMAMS;
        private System.Windows.Forms.MaskedTextBox txtGeboorteDatumPAPS;
        private System.Windows.Forms.MaskedTextBox txtGeboorteDatumSPAPS;
        private System.Windows.Forms.MaskedTextBox txtGeboorteDatumSMAMS;
        private System.Windows.Forms.ComboBox cboGeslacht;
        private System.Windows.Forms.ComboBox cboGeboorte;
        private System.Windows.Forms.ComboBox txtNationaliteit;
        private System.Windows.Forms.ComboBox txtPostcode;
        private System.Windows.Forms.ComboBox txtLand;
        private System.Windows.Forms.ComboBox txtStudieKeuze;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}

