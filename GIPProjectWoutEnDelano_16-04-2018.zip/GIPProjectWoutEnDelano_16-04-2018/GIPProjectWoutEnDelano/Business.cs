﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Business
    {
        Persistence pers;

        public Business()
        {pers = new Persistence();}

        public void voegNatToe(string pNationaliteit)
        {
            Nationaliteit Nat = new Nationaliteit(pNationaliteit);
            pers.AddNat(Nat);
        }

        public void voegLandToe(string pLand)
        {
            Land Nland = new Land(pLand);
            pers.AddLand(Nland);
        }

        public void VoegGemeenteToe(string pnaam, string pstrPostCode)
        {
            gemeente gem = new gemeente(pnaam, pstrPostCode);
            pers.AddGemeente(gem);
        }

        public void VoegLeerlingToe(string pnaam, string pVoorNaam, DateTime pgeboorte, string pStudie, string pBijkNaam, string pGsm, string pGeboorteplaats, string pNationaliteit, string pRijksregister, string pGeslacht, string pEmail, string pstrStraat, string pstrHuisnummer, string pstrBus, string pstrLand, string PstrPostcode)
        {
            Leerling lln = new Leerling(pnaam, pVoorNaam, pgeboorte, pStudie, pBijkNaam, pGsm, pGeboorteplaats, pNationaliteit, pRijksregister, pGeslacht, pEmail, pstrStraat, pstrHuisnummer, pstrBus, pstrLand, PstrPostcode);
            pers.AddLeerling(lln);
        }

        public void VoegGezinToe(string pdomicilieTel, string pdomicilieGSM, string pOudersGSM, string pEmailOuders)
        {
            Gezin gzn = new Gezin(pdomicilieTel, pdomicilieGSM, pOudersGSM, pEmailOuders);
            pers.AddGezin(gzn);
        }

        public void VoegmamaToe(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep, string pWerktel, string pGsm, string pRijksregister, string pEmail, string strRol)
        {
            Gezinslid mama = new Gezinslid(pnaam, pVoorNaam, pgeboorte, pBeroep, pWerktel, pGsm, pRijksregister, pEmail, strRol);
            pers.AddMoeder(mama);
        }

        public void VoegpapaToe(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep, string pWerktel, string pGsm, string pRijksregister, string pEmail, string strRol)
        {
            Gezinslid papa = new Gezinslid(pnaam, pVoorNaam, pgeboorte, pBeroep, pWerktel, pGsm, pRijksregister, pEmail, strRol);
            pers.AddVader(papa);
        }

        public void VoegstiefmamaToe(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep, string pGsm, string pEmail, string strRol)
        {
            Gezinslid stiefmama = new Gezinslid(pnaam, pVoorNaam, pgeboorte, pBeroep, pGsm, pEmail, strRol);
            pers.AddStiefMoeder(stiefmama);
        }

        public void VoegstiefpapaToe(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep, string pGsm, string pEmail, string strRol)
        {
            Gezinslid stiefpapa = new Gezinslid(pnaam, pVoorNaam, pgeboorte, pBeroep, pGsm, pEmail, strRol);
            pers.AddStiefVader(stiefpapa);
        }

        public void VoegInschrijvingToe()
        {
            Inschrijving Ins = new Inschrijving();
            pers.Addinschrijving(Ins);
        }

        public List<string> toonPostcode()
        {
            List<string> list = new List<string>();

            foreach(gemeente item in pers.getGemeente())
            {
                list.Add(item.Postcode); 
            }

            return list;
        }

        public List<string> toonNationaliteit()
        {
            List<string> list = new List<string>();

            foreach (Nationaliteit item in pers.getNationaliteit())
            {
                list.Add(item.Nationality);
            }

            return list;
        }

        public List<string> toonLand()
        {
            List<string> list = new List<string>();

            foreach (Land item in pers.getLand())
            {
                list.Add(item.land);
            }

            return list;
        }

        public List<string> toonRichting()
        {
            List<string> list = new List<string>();

            foreach (richting item in pers.getRichting())
            {
                list.Add(item.naam);
            }

            return list;
        }

    }
}
