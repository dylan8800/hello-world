﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GIPProjectWoutEnDelano
{
    
    public partial class inschrijvingsformulier : Form
    {
        Business bus = new Business();

        public inschrijvingsformulier()
        {
            InitializeComponent();
        }

        private void start_Load(object sender, EventArgs e)
        {
            foreach (string item in bus.toonLand())
            {
                txtLand.Items.Add(item);
            }
            foreach (string item in bus.toonNationaliteit())
            {
                txtNationaliteit.Items.Add(item);
            }
            foreach (string item in bus.toonPostcode())
            {
                txtPostcode.Items.Add(item);
            }
            foreach(string item in bus.toonRichting())
            {
                txtStudieKeuze.Items.Add(item);
            }
        }
        
        private void btnVoegToe_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNaam.Text) || string.IsNullOrWhiteSpace(txtVoorNaam.Text) || string.IsNullOrWhiteSpace(txtGeboorteDatum.Text) || string.IsNullOrWhiteSpace(txtStudieKeuze.Text) || string.IsNullOrWhiteSpace(txtBijkVoorNamen.Text) || string.IsNullOrWhiteSpace(txtGsmEigen.Text) 
                || string.IsNullOrWhiteSpace(cboGeboorte.Text) || string.IsNullOrWhiteSpace(txtNationaliteit.Text) || string.IsNullOrWhiteSpace(txtRijksregisternummer.Text) || string.IsNullOrWhiteSpace(cboGeslacht.Text) || string.IsNullOrWhiteSpace(txtEmailLeerling.Text) || string.IsNullOrWhiteSpace(txtStraat.Text) || string.IsNullOrWhiteSpace(txtHuisNummer.Text) || string.IsNullOrWhiteSpace(txtBus.Text) 
                || string.IsNullOrWhiteSpace(txtTelefoonDomicilie.Text) || string.IsNullOrWhiteSpace(txtgsmDomicilie.Text) || string.IsNullOrWhiteSpace(txtGSMouders.Text) || string.IsNullOrWhiteSpace(txtEmailOuders.Text) || string.IsNullOrWhiteSpace(txtNaamMoeder.Text) || string.IsNullOrWhiteSpace(txtVoornaamMoeder.Text) 
                || string.IsNullOrWhiteSpace(txtGeboortedatumMAMS.Text) || string.IsNullOrWhiteSpace(txtBeroepMoeder.Text) || string.IsNullOrWhiteSpace(txtWerkTelMoeder.Text) || string.IsNullOrWhiteSpace(txtGSMmoeder.Text) || string.IsNullOrWhiteSpace(txtRijksregisterNummerMoeder.Text) || string.IsNullOrWhiteSpace(txtEmailMoeder.Text)
                || string.IsNullOrWhiteSpace(txtNaamVader.Text) || string.IsNullOrWhiteSpace(txtVoornaamVader.Text) || string.IsNullOrWhiteSpace(txtGeboorteDatumPAPS.Text) || string.IsNullOrWhiteSpace(txtBeroepVader.Text) || string.IsNullOrWhiteSpace(txtWerkTelVader.Text) || string.IsNullOrWhiteSpace(txtGSMvader.Text) || string.IsNullOrWhiteSpace(txtRijksregisternummerVader.Text) || string.IsNullOrWhiteSpace(txtEmailVader.Text))
            {
                MessageBox.Show("niet alle nodige velden zijn ingevuld!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string strMama = "mama", strPapa = "papa", strStiefPapa = "stiefpapa", strStiefMama = "stiefmama";

                //bus.voegNatToe(txtNationaliteit.Text);
                //bus.voegLandToe(txtLand.Text);
                //bus.VoegGemeenteToe(txtGemeente.Text, txtPostcode.Text);
                bus.VoegLeerlingToe(txtNaam.Text, txtVoorNaam.Text, Convert.ToDateTime(txtGeboorteDatum.Text), txtStudieKeuze.Text, txtBijkVoorNamen.Text, txtGsmEigen.Text, cboGeboorte.Text, txtNationaliteit.Text, txtRijksregisternummer.Text, cboGeslacht.Text, txtEmailLeerling.Text, txtStraat.Text, txtHuisNummer.Text, txtBus.Text, txtLand.Text, txtPostcode.Text);
                bus.VoegGezinToe(txtTelefoonDomicilie.Text, txtgsmDomicilie.Text, txtGSMouders.Text, txtEmailOuders.Text);
                bus.VoegmamaToe(txtNaamMoeder.Text, txtVoornaamMoeder.Text, Convert.ToDateTime(txtGeboortedatumMAMS.Text), txtBeroepMoeder.Text, txtWerkTelMoeder.Text, txtGSMmoeder.Text, txtRijksregisterNummerMoeder.Text, txtEmailMoeder.Text, strMama);
                bus.VoegpapaToe(txtNaamVader.Text, txtVoornaamVader.Text, Convert.ToDateTime(txtGeboorteDatumPAPS.Text), txtBeroepVader.Text, txtWerkTelVader.Text, txtGSMvader.Text, txtRijksregisternummerVader.Text, txtEmailVader.Text, strPapa);
                bus.VoegstiefmamaToe(txtNaamStiefmoeder.Text, txtVoornaamStiefmoeder.Text, Convert.ToDateTime(txtGeboorteDatumSMAMS.Text), txtBeroepStiefmoeder.Text, txtGSMstiefmoeder.Text, txtEmailStiefmoeder.Text, strStiefMama);
                bus.VoegstiefpapaToe(txtNaamStiefvader.Text, txtVoornaamStiefvader.Text, Convert.ToDateTime(txtGeboorteDatumSPAPS.Text), txtBeroepStiefVader.Text, txtGSMstiefvader.Text, txtEmailStiefvader.Text, strStiefPapa);
                bus.VoegInschrijvingToe();
            }
            // tabindex van emailvader is 36 en er worden maar 34 txt's toegevoegd als je strMama of strPapa niet meeteld (en ook stiefma en stiefpa)
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtStraat_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBus_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBijkVoorNamen_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtEmailStiefvader_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
