﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class richting
    {
        private string strRichting;

        public string naam
        {
            get { return strRichting; }
            set { strRichting = value; }
        }

        public richting(string pstrRichting)
        {
            strRichting = pstrRichting;
        }
    }
}
