﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Inschrijving
    {
        private string strTime, strAanmeldingstijd;

        public Inschrijving()
        {
            strTime = DateTime.Now.ToString("h:mm:ss");
            strAanmeldingstijd = DateTime.Today.DayOfWeek.ToString();
        }

        public string Aanmeldingstijd
        {
            get { return strAanmeldingstijd; }
        }

        public string Time
        {
            get { return strTime; }
        }


    }
}
