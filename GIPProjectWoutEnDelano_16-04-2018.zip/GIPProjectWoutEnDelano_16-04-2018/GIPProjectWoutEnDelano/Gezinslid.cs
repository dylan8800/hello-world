﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Gezinslid
    {
        private string strNaam, strVoornaam, strGSM, strBeroep, strWerkTel,strRijksregister,strEmail, strRol;
        private DateTime dteGeboorte;

        public string Rol 
        {
            get { return strRol; }
            set { strRol = value; }
        }

        public string Naam
        {
            get { return strNaam; }
            set { strNaam = value; }
        }
        public string Voornaam
        {
            get { return strVoornaam; }
            set { strVoornaam = value; }
        }
        public string Gsm
        {
            get { return strGSM; }
            set { strGSM = value; }
        }
        public string Beroep
        {
            get { return strBeroep; }
            set { strBeroep = value; }
        }
        public string WerkTel
        {
            get { return strWerkTel; }
            set { strWerkTel = value; }
        }
        public string Rijksregisternr
        {
            get { return strRijksregister; }
            set { strRijksregister = value; }
        }
        public string Email
        {
            get { return strEmail; }
            set { strEmail = value; }
        }
        public DateTime GeboorteDatum
        {
            get { return dteGeboorte; }
            set { dteGeboorte = value; }
        }


        public Gezinslid(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep, string pWerktel, string pGsm, string pRijksregister, string pEmail, string pstrRol)
        {
            strNaam = pnaam;
            strVoornaam = pVoorNaam;
            dteGeboorte = pgeboorte;
            strBeroep = pBeroep;
            strWerkTel = pWerktel;
            strGSM = pGsm;
            strRijksregister = pRijksregister;
            strEmail = pEmail;
            strRol = pstrRol;
        }


        public Gezinslid(string pnaam, string pVoorNaam, DateTime pgeboorte, string pBeroep,  string pGsm, string pEmail, string pstrRol)
        {
            strNaam = pnaam;
            strVoornaam = pVoorNaam;
            dteGeboorte = pgeboorte;
            strBeroep = pBeroep;
            strGSM = pGsm;
            strEmail = pEmail;
            strRol = pstrRol;
        }
    }
}
