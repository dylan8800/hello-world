﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIPProjectWoutEnDelano
{
    class Gezin
    {
        private string strDomicilieTel, strDomicilieGSM,strOudersGSM,strEmailOuders;

        public string DomicilieTel
        {
            get { return strDomicilieTel; }
            set { strDomicilieTel = value; }
        }

        public string DomicilieGSM
        {
            get { return strDomicilieGSM; }
            set { strDomicilieGSM = value; }
        }

        public string OudersGSM
        {
            get { return strOudersGSM; }
            set { strOudersGSM = value; }
        }

        public string EmailOuders
        {
            get { return strEmailOuders; }
            set { strEmailOuders = value; }
        }

        public Gezin(string pdomicilieTel,string pdomicilieGSM,string pOudersGSM,string pEmailOuders)
        {
            strDomicilieTel = pdomicilieTel;
            strDomicilieGSM = pdomicilieGSM;
            strOudersGSM = pOudersGSM;
            strEmailOuders = pEmailOuders;
        }
    }
}
