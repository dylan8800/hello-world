-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema gip
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema gip
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gip` DEFAULT CHARACTER SET utf8 ;
USE `gip` ;

-- -----------------------------------------------------
-- Table `gip`.`gezin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gip`.`gezin` (
  `idgezin` INT(11) NOT NULL AUTO_INCREMENT,
  `DomicilieTel` VARCHAR(45) NOT NULL,
  `OudersGSM` VARCHAR(45) NOT NULL,
  `EmailOuders` VARCHAR(45) NOT NULL,
  `DomicilGSM` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idgezin`))
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gip`.`gezinslid`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gip`.`gezinslid` (
  `idgezinslid` INT(11) NOT NULL AUTO_INCREMENT,
  `naam` VARCHAR(45) NOT NULL,
  `Voornaam` VARCHAR(45) NOT NULL,
  `Gsm` VARCHAR(45) NOT NULL,
  `Beroep` VARCHAR(45) NOT NULL,
  `WerkTel` VARCHAR(45) NULL DEFAULT NULL,
  `Rijksregisternr` VARCHAR(45) NOT NULL,
  `Email` VARCHAR(45) NOT NULL,
  `GeboorteDatum` VARCHAR(45) NOT NULL,
  `Rol` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idgezinslid`),
  UNIQUE INDEX `gsm_UNIQUE` (`Beroep` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 36
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gip`.`inschrijving`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gip`.`inschrijving` (
  `idinschrijving` INT(11) NOT NULL AUTO_INCREMENT,
  `Aanmeldingstijd` VARCHAR(45) NOT NULL,
  `Tijd` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idinschrijving`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gip`.`leerling`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gip`.`leerling` (
  `idLeerling` INT(11) NOT NULL AUTO_INCREMENT,
  `naam` VARCHAR(45) NOT NULL,
  `voornaam` VARCHAR(45) NOT NULL,
  `geboortedatum` DATE NOT NULL,
  `studierichting` VARCHAR(45) NOT NULL,
  `bijknaam` VARCHAR(45) NOT NULL,
  `gsm` VARCHAR(45) NOT NULL,
  `geboorteplaats` VARCHAR(45) NOT NULL,
  `nationaliteit` VARCHAR(45) NOT NULL,
  `rijksrigister` VARCHAR(45) NOT NULL,
  `Straat` VARCHAR(45) NOT NULL,
  `huisnummer` VARCHAR(45) NOT NULL,
  `bus` VARCHAR(45) NOT NULL,
  `postcode` VARCHAR(45) NOT NULL,
  `land` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idLeerling`),
  UNIQUE INDEX `idLeerling_UNIQUE` (`idLeerling` ASC),
  UNIQUE INDEX `rijksrigister_UNIQUE` (`rijksrigister` ASC),
  UNIQUE INDEX `gsm_UNIQUE` (`gsm` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
