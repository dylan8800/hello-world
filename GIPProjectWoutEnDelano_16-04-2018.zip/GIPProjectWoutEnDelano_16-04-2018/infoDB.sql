-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema dbsteden
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema dbsteden
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `dbsteden` DEFAULT CHARACTER SET utf8 ;
USE `dbsteden` ;

-- -----------------------------------------------------
-- Table `dbsteden`.`gemeenten`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbsteden`.`gemeenten` (
  `idGemeenten` INT(11) NOT NULL AUTO_INCREMENT,
  `Postcode` VARCHAR(45) NOT NULL,
  `Naam` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idGemeenten`),
  UNIQUE INDEX `idGemeenten_UNIQUE` (`idGemeenten` ASC),
  UNIQUE INDEX `Naam_UNIQUE` (`Postcode` ASC),
  UNIQUE INDEX `Postcode_UNIQUE` (`Naam` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 22
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `dbsteden`.`landen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbsteden`.`landen` (
  `idlanden` INT(11) NOT NULL AUTO_INCREMENT,
  `naam` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idlanden`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `dbsteden`.`nationaliteit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbsteden`.`nationaliteit` (
  `idnationaliteit` INT(11) NOT NULL AUTO_INCREMENT,
  `nationaliteit` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idnationaliteit`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `dbsteden`.`richtingen`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbsteden`.`richtingen` (
  `idRichtingen` INT(11) NOT NULL AUTO_INCREMENT,
  `richtingen` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idRichtingen`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
